import pygame
import os

BIRD_IMGS = [pygame.transform.scale_by(surface=pygame.image.load(os.path.join("images", "bird1.png")), factor=1.5),
             pygame.transform.scale_by(surface=pygame.image.load(os.path.join("images", "bird2.png")), factor=1.5),
             pygame.transform.scale_by(surface=pygame.image.load(os.path.join("images", "bird3.png")), factor=1.5)]


class Bird:
    IMGS = BIRD_IMGS
    MAX_ROTATION = 25
    ROTATION_VEL = 20
    ANIMATION_TIME = 5

    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.tilt = 0
        self.tick_count = 0
        self.vel = 0
        self.height = self.y
        self.img_count = 0
        self.img = self.IMGS[0]

    def jump(self):
        self.vel = -12
        self.tick_count = 0
        self.height = self.y

    def move(self):
        self.tick_count += 1

        gravity = 0.8
        air_resistance = 0.95
        max_fall_speed = 10

        self.vel += gravity

        if self.vel > 0:
            self.vel *= air_resistance

        if self.vel > max_fall_speed:
            self.vel = max_fall_speed

        self.y += self.vel

        if self.vel < 0 or self.y < self.height + 50:
            if self.tilt < self.MAX_ROTATION:
                self.tilt = self.MAX_ROTATION
        else:
            if self.tilt > -90:
                self.tilt -= self.ROTATION_VEL

    def draw(self, win):
        self.img_count += 1

        if self.img_count < self.ANIMATION_TIME:
            self.img = self.IMGS[0]
        elif self.img_count < self.ANIMATION_TIME*2:
            self.img = self.IMGS[1]
        elif self.img_count < self.ANIMATION_TIME*3:
            self.img = self.IMGS[2]
        elif self.img_count < self.ANIMATION_TIME*4:
            self.img = self.IMGS[1]
        elif self.img_count == self.ANIMATION_TIME*4 + 1:
            self.img = self.IMGS[0]
            self.img_count = 0

        if self.tilt <= -80:
            self.img = self.IMGS[1]
            self.img_count = self.ANIMATION_TIME*2

        rotated_image = pygame.transform.rotate(self.img, self.tilt)
        new_rect = rotated_image.get_rect(center=self.img.get_rect(topleft=(self.x, self.y)).center)
        win.blit(rotated_image, new_rect.topleft)

    def get_mask(self):
        return pygame.mask.from_surface(self.img)
